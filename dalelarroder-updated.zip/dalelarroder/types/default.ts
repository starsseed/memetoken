export enum EnvironmentType {
  Dev = 'development',
  Prod = 'production',
  Test = 'test',
}

export const POSTS_PER_PAGE = 5;
